package assignment1restfulclient;

import java.io.IOException;
import java.util.Scanner;
import org.netbeans.saas.root.RootapplicationWadl;
import org.netbeans.saas.RestResponse;

public class Assignment1RestfulCLient {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        // Loop breaker
        boolean quitFlag = false;
        // Whole program wrapped around a loop

        while (!quitFlag) {
            System.out.println("Please enter 1-7\n1.help / about (displays the generic information about your program)"
                    + "\n2.list (shows the list of current books, id and title)"
                    + "\n3.display book (displays the book info by getting the id from the user)"
                    + "\n4.add book (adds a new book to the system, data to be given in the console by the user)"
                    + "\n5.update book (updates specific book, id and the data to be given in the console by the user)"
                    + "\n6.delete book (deletes a book, id to be given in the console by the user)"
                    + "\n7.Exit");
            int check = in.nextInt();
            switch (check) {
                case 1:
                    System.out.println("The program implements a RESTful Web Service for a library system.\n"
                            + "The library system stores the information for books. The system maintains the following information for each book:\n"
                            + "• title\n"
                            + "• description\n"
                            + "• isbn\n"
                            + "• author\n"
                            + "• publisher\n");
                    break;
                case 2:

                    try {

                        RestResponse result = RootapplicationWadl.getPlain();
                        System.out.println("List of current books:\n " + result.getDataAsString());
                    } catch (IOException ex) {
                    }
                    break;
                case 3:

                    try {
                        Scanner scan = new Scanner(System.in);
                        System.out.println("Enter a book's id to retrieve from the library: ");
                        Integer id = scan.nextInt();
                        RestResponse result1 = RootapplicationWadl.getPlainId();

                        System.out.println("Book:\n " + result1.getDataAsString());
                    } catch (IOException ex) {
                    }
                    break;

                case 4:
                    try {
                        Scanner scan = new Scanner(System.in);
                        System.out.println("Enter a book's title: ");
                        String title = scan.nextLine();
                        System.out.println("Enter a book's description: ");
                        String description = scan.nextLine();
                        System.out.println("Enter a book's isbn: ");
                        String isbn = scan.nextLine();
                        System.out.println("Enter a book's author: ");
                        String author = scan.nextLine();
                        System.out.println("Enter a book's publisher: ");
                        String publisher = scan.nextLine();
                        RestResponse result2 = RootapplicationWadl.create(title, description, isbn, author, publisher);

                        System.out.println(result2.getDataAsString());
                    } catch (IOException ex) {
                    }
                    break;
                case 5:

                    try {
                        Scanner scan1 = new Scanner(System.in);
                        System.out.println("Enter a book's ID to update: ");
                        Integer id = scan1.nextInt();
                        Scanner scan2 = new Scanner(System.in);
                        System.out.println("Enter a new book's title: ");
                        String title = scan2.nextLine();
                        System.out.println("Enter a new book's description: ");
                        String description = scan2.nextLine();
                        System.out.println("Enter a new book's isbn: ");
                        String isbn = scan2.nextLine();
                        System.out.println("Enter a new book's author: ");
                        String author = scan2.nextLine();
                        System.out.println("Enter a new book's publisher: ");
                        String publisher = scan2.nextLine();

                        RestResponse result3 = RootapplicationWadl.update(id, title, description, isbn, author, publisher);

                        System.out.println("Updated book's information returned: " + result3.getDataAsString());
                    } catch (IOException ex) {
                    }
                    break;

                case 6:

                    try {
                        Scanner scan1 = new Scanner(System.in);
                        System.out.println("Enter a book's ID to delete: ");
                        Integer id = scan1.nextInt();
                        RestResponse result4 = RootapplicationWadl.delete();

                        System.out.println("Book with " + id + "deleted" + result4.getDataAsString());
                    } catch (IOException ex) {
                    }
                    break;
                case 7:
                    quitFlag = true;
                    System.out.println("Bye!");
                    break;
            }
        }
    }
}

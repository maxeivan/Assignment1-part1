/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.netbeans.saas.root;

import java.io.IOException;
import org.netbeans.saas.RestConnection;
import org.netbeans.saas.RestResponse;

/**
 * RootapplicationWadl Service
 *
 * @author Maxim
 */
public class RootapplicationWadl {

    /**
     * Creates a new instance of RootapplicationWadl
     */
    public RootapplicationWadl() {
    }
    
    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (Throwable th) {
        }
    }

    /**
     *
     * @return an instance of RestResponse
     */
    public static RestResponse getPlain() throws IOException {
        String[][] pathParams = new String[][]{};
        String[][] queryParams = new String[][]{};
        RestConnection conn = new RestConnection("http://localhost:8084/Assignment1/webresources/ites/plain", pathParams, queryParams);
        sleep(1000);
        return conn.get(null);
    }

    /**
     *
     * @return an instance of RestResponse
     */
    public static RestResponse getPlainId() throws IOException {
        String[][] pathParams = new String[][]{};
        String[][] queryParams = new String[][]{};
        RestConnection conn = new RestConnection("http://localhost:8084/Assignment1/webresources/ites/plain/{id: d+}", pathParams, queryParams);
        sleep(1000);
        return conn.get(null);
    }

    /**
     *
     * @param title
     * @param description
     * @param isbn
     * @param author
     * @param publisher
     * @return an instance of RestResponse
     */
    public static RestResponse create(String title, String description, String isbn, String author, String publisher) throws IOException {
        String[][] pathParams = new String[][]{};
        String[][] queryParams = new String[][]{{"title", title}, {"description", description}, {"isbn", isbn}, {"author", author}, {"publisher", publisher}};
        RestConnection conn = new RestConnection("http://localhost:8084/Assignment1/webresources/ites/create", pathParams, null);
        sleep(1000);
        return conn.post(null, queryParams);
    }

    /**
     *
     * @param id
     * @param title
     * @param description
     * @param isbn
     * @param author
     * @param publisher
     * @return an instance of RestResponse
     */
    public static RestResponse update(Integer id, String title, String description, String isbn, String author, String publisher) throws IOException {
        String[][] pathParams = new String[][]{};
        String[][] queryParams = new String[][]{{"id", id.toString()}, {"title", title}, {"description", description}, {"isbn", isbn}, {"author", author}, {"publisher", publisher}};
        RestConnection conn = new RestConnection("http://localhost:8084/Assignment1/webresources/ites/update", pathParams, null);
        sleep(1000);
        return conn.put(null, queryParams);
    }

    /**
     *
     * @return an instance of RestResponse
     */
    public static RestResponse delete() throws IOException {
        String[][] pathParams = new String[][]{};
        String[][] queryParams = new String[][]{};
        RestConnection conn = new RestConnection("http://localhost:8084/Assignment1/webresources/ites/delete/{id: d+}", pathParams, queryParams);
        sleep(1000);
        return conn.delete(null);
    }
}

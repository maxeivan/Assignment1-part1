/*
 * This class represents a collection of book instances,
 * with the collection implemented as a thread-safe CopyOnWriteArrayList
 */
package assignment1;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "bookrepository")
public class BookRepository {

    private List<Book> books;
    
    //Integer id of each book added to the list generated with a thread-safe AtomicInteger
    private AtomicInteger bookId;

    public BookRepository() {
        books = new CopyOnWriteArrayList<Book>();
        bookId = new AtomicInteger();
    }

    @XmlElement
    @XmlElementWrapper(name = "books")
    public List<Book> getBooks() {
        return this.books;
    }

    /**
     *
     * @param books
     */
    public void setBooks(List<Book> books) {
        this.books = books;
    }

    @Override
    //For response in plain-text format, turn list of books (Object) into String
    public String toString() {
        String s = "";
        for (Book b : books) {
            s += b.toString();
        }
        return s;
    }

    public Book find(int id) {
        Book book = null;

        for (Book b : books) {
            if (b.getId() == id) {
                book = b;
                break;
            }
        }
        return book;
    }

    /**
     *
     * @param title
     * @param description
     * @param isbn
     * @param author
     * @param publisher
     * @return
     */
    public int add(String title, String description, String isbn, String author, String publisher) {
        int id = bookId.incrementAndGet();
        Book b = new Book();
        b.setTitle(title);
        b.setDescription(description);
        b.setId(id);
        b.setIsbn(isbn);
        b.setAuthor(author);
        b.setPublisher(publisher);
        books.add(b);
        return id;
    }
}

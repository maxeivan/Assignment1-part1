/**
 * The Book class is a POJO class with five properties.
 * There is also an id property whose value uniquely identifies each Book
 * instance; book instances are stored, in ascending order by id, in a
 * BookRepository class
 */
package assignment1;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
//Book class implements the Comparable interface in case sorting is needed

@XmlRootElement(name = "book")
public class Book implements Comparable<Book> {

    private int id;
    private String title;
    private String description;
    private String isbn;
    private String author;
    private String publisher;

    public Book() {
    }

    @Override
    public String toString() {
        return String.format("%2d: ", id) + title + " " + description + " "
                + isbn + " " + author + " " + publisher + "\n";
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @XmlElement
    public String getTitle() {
        return this.title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlElement
    public String getDescription() {
        return this.description;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @XmlElement
    public String getIsbn() {
        return this.isbn;
    }

    public void setId(int id) {
        this.id = id;
    }

    @XmlElement
    public int getId() {
        return this.id;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @XmlElement
    public String getAuthor() {
        return this.author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @XmlElement
    public String getPublisher() {
        return this.publisher;
    }

    @Override
    public int compareTo(Book other) {
        return this.id - other.id;
    }

}

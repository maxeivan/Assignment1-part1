/*
 * Library class is the JAX-RS resource with annotations that define the CRUD operations.
 */
package assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.servlet.ServletContext;
import javax.ws.rs.DELETE;
import javax.ws.rs.core.Context;
import javax.ws.rs.PathParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/ites")
public class Library {

    @Context
    //Declare a ServletContext object that corresponds to a specified URL on the server
    private ServletContext sctx;
    //Declare a list of books set in populate()
    private static BookRepository blist;

    public Library() {
    }

    /*There are two operations annotated with GET.
    The first GET operation returns the entire list of books in plain-text format.
     */
    /**
     *
     * @return
     */
    @GET
    @Path("/plain")
    @Produces({MediaType.TEXT_PLAIN})
    public String getPlain() {
        checkContext();
        return blist.toString();
    }
    
    //The second GET is parametrized with id. If successful it returns a single book
    /**
     *
     * @param id
     * @return
     */
    @GET
    @Path("/plain/{id: \\d+}")
    @Produces({MediaType.TEXT_PLAIN})
    public String getPlainId(@PathParam("id") int id) {
        checkContext();
        return toRequestedType(id);
    }
    //Retrieve a book from the list of books as per id of the book
    private String toRequestedType(int id) {
        
        //Find the book in the list of books
        Book book = blist.find(id);
        if (book == null) {
            String msg = id + " is a bad ID.\n";
            return msg;
        } else {
            return book.toString();
        }
    }

    /**
     * The operation annotated with POST implements create CRUD operation
     *
     * @param title
     * @param description
     * @param isbn
     * @param author
     * @param publisher
     * @return
     */
    @POST
    @Produces({MediaType.TEXT_PLAIN})
    @Path("/create")
    public Response create(@FormParam("title") String title,
            @FormParam("description") String description,
            @FormParam("isbn") String isbn,
            @FormParam("author") String author,
            @FormParam("publisher") String publisher) {
        checkContext();
        String msg = null;
        // Require all five properties to create.
        if (title == null || description == null || isbn == null || author == null || publisher == null) {
            msg = "Property 'title' or 'description' or 'isbn' or 'author' or 'publisher' is missing.\n";
            return Response.status(Response.Status.BAD_REQUEST).
                    entity(msg).
                    type(MediaType.TEXT_PLAIN).
                    build();
        }
        // Otherwise, create the book and add it to the collection.
        int id = addBook(title, description, isbn, author, publisher);
        msg = "Book " + id
                + " created: (title = " + title + " description = " + description + " isbn = "
                + isbn + " author = " + author + " publisher = " + publisher + ").\n";
        return Response.ok(msg, "text/plain").build();
    }

    /**
     * The operation annotated with PUT implements update CRUD operation
     *
     * @param id
     * @param title
     * @param description
     * @param isbn
     * @param author
     * @param publisher
     * @return
     */
    @PUT
    @Produces({MediaType.TEXT_PLAIN})
    @Path("/update")
    public Response update(@FormParam("id") int id,
            @FormParam("title") String title,
            @FormParam("description") String description,
            @FormParam("isbn") String isbn,
            @FormParam("author") String author,
            @FormParam("publisher") String publisher) {
        checkContext();
        // Verify that at least one property is present to do an edit.
        String msg = null;
        if (title == null && description == null && isbn == null && author == null && publisher == null) {
            msg = "No new piece of information is given: nothing to edit.\n";
        }
        Book b = blist.find(id);
        if (b == null) {
            msg = "There is no book with ID " + id + "\n";
        }

        if (msg != null) {
            return Response.status(Response.Status.BAD_REQUEST).
                    entity(msg).
                    type(MediaType.TEXT_PLAIN).
                    build();
        }
        // Update.
        if (title != null) {
            b.setTitle(title);
        }
        if (description != null) {
            b.setDescription(description);
        }
        if (isbn != null) {
            b.setIsbn(isbn);
        }

        if (author != null) {
            b.setAuthor(author);
        }
        if (publisher != null) {
            b.setPublisher(publisher);
        }
        msg = "Book " + id + " has been updated.\n";
        return Response.ok(msg, "text/plain").build();
    }

    /**
     * The operation annotated with DELETE implements delete CRUD operation
     *
     * @param id
     * @return
     */
    @DELETE
    @Produces({MediaType.TEXT_PLAIN})
    @Path("/delete/{id: \\d+}")
    public Response delete(@PathParam("id") int id) {
        checkContext();
        String msg = null;
        Book b = blist.find(id);
        if (b == null) {
            msg = "There is no book with ID " + id + ". Cannot delete.\n";
            return Response.status(Response.Status.BAD_REQUEST).
                    entity(msg).
                    type(MediaType.TEXT_PLAIN).
                    build();
        }
        blist.getBooks().remove(b);
        msg = "Book " + id + " deleted.\n";
        return Response.ok(msg, "text/plain").build();
    }
    
    //Verify if the list of books is empty
    private void checkContext() {
        if (blist == null) {
            populate();
        }
    }
    //Populate empty list of books from a file
    private void populate() {
        blist = new BookRepository();
        String filename = "/WEB-INF/data/books.csv";
        InputStream in = sctx.getResourceAsStream(filename);
        // Read the data from the file into the array of books
        if (in != null) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String record = null;
                while ((record = reader.readLine()) != null) {
                    String[] parts;
                    parts = record.split(",");
                    //Call this method to add a book with parameters from the file into BookRepository
                    addBook(parts[0], parts[1], parts[2], parts[3], parts[4]);
                }
            } catch (IOException e) {
                throw new RuntimeException("I/O failed!");
            }
        }
    }
    //Add a new book in BookRepository class 
    private int addBook(String title, String description, String isbn, String author, String publisher) {
        
        //Create and add the new book into the list of books and return id of the new book
        int id = blist.add(title, description, isbn, author, publisher);
        return id;
    }
    
}

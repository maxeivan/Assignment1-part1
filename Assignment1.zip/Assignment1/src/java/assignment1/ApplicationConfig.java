/**
 * The ApplicationConfig class extends the JAX-RS Application class.
 * Jersey ServletContainer finds the ApplicationConfig instance and 
 * invokes its getClasses method to identify the RESTful resources: Library class
*/

package assignment1;

import java.util.Set;
import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * addRestResourceClasses() method is automatically
     * populated with all resources defined in the project.
     * 
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(assignment1.Library.class);
    }

}
